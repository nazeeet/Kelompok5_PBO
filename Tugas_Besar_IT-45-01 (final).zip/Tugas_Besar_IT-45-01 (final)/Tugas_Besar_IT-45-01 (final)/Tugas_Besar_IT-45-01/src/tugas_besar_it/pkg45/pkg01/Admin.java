
package tugas_besar_it.pkg45.pkg01;


public class Admin {
    private int id;
    private String nama;

    public Admin(String nama, int id) {
        this.nama = nama;
        this.id = id;
    }
    
    public String getNama() {
        return nama;
    }
  
}
