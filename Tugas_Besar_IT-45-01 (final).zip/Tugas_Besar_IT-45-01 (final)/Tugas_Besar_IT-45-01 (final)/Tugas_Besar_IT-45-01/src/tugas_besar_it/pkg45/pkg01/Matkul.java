package tugas_besar_it.pkg45.pkg01;

public class Matkul {
    private String kodematkul;
    private String namamatkul;

    public Matkul(String kodematkul, String namamatkul) {
        this.kodematkul = kodematkul;
        this.namamatkul = namamatkul;
    }

    public String getKodematkul() {
        return kodematkul;
    }

    public String getNamamatkul() {
        return namamatkul;
    }   
}
