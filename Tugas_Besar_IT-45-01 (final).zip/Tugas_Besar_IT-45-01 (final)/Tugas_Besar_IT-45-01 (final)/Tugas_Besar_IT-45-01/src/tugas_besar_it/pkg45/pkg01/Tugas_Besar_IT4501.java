package tugas_besar_it.pkg45.pkg01;

public class Tugas_Besar_IT4501 {

    public static void main(String[] args) {
        Login login = new Login();
        login.setVisible(true);
    }
}
