package tugas_besar_it.pkg45.pkg01;

public class Mahasiswa {
    private String nama;

    public Mahasiswa(String nama) {
        this.nama = nama;   
    }
    
    public String getNama() {
        return nama;
    }   
}
